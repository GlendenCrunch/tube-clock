#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdbool.h>
#include <pcf8563.h>
#include <eeprom.h>

#define del_vt 1              // delay for transistor --> anod
#define freq_mosfet 243		//243
#define freq_rtc 33938

#define blue (pow(2,6))
#define red (pow(2,14))
#define green (pow(2,22))
#define aqumarine (blue+red)
#define yellow (red+green)
#define purpure (green+blue)

PCF_DateTime pcfDateTime;
unsigned long int rgb_list1[6]={};
int led1count = 0;
int led2count = 0;
int led3count = 0;
int menuTimePressed=0;
int menuDatePressed=0;
int menLedPressed=0;
int menuCommonPressed=0;
_Bool menuCommon = true;
_Bool menuTime = true;
_Bool menuDate = false;
_Bool menuLed = false;
_Bool hourMode = false;
_Bool minuteMode = false;
_Bool dayMode = false;
_Bool monthMode = false;
_Bool yearMode = false;
_Bool led1Mode = false;
_Bool led2Mode = false;
_Bool led3Mode = false;
/* ----------------------- config timers ------------------------------- */
void init_timer0(void)
{
  TCCR0A |= (0<<COM0A1)|(0<<COM0A0);
  TCCR0A |= (0<<COM0B1)|(0<<COM0B0);
  TCCR0A |= (0<<WGM02)|(0<<WGM01)|(0<<WGM00); // normal
  TCCR0B = (1<<CS02)|(0<<CS01)|(0<<CS00);     // prescaler (010:8; 011:64; 100:256)
  TIMSK0 = 1<<TOIE0;                          // Overflow Interrupt Enable
  TIFR0  = 1<<TOV0;                           // Clear overflow flag
}
void init_timer1(void)
{
  TCCR1A |= (0<<COM1A1)|(0<<COM1A0);
  TCCR1A |= (0<<COM1B1)|(0<<COM0B0);
  TCCR1A |= (0<<WGM12)|(0<<WGM11)|(0<<WGM10); // normal
  TCCR1B = (1<<CS12)|(0<<CS11)|(0<<CS10);     // prescaler (010:8; 011:64; 100:256)
  TIMSK1 = 1<<TOIE1;                          // Overflow Interrupt Enable
  TIFR1  = 1<<TOV1;                           // Clear overflow flag
}
/* ---------------------- freq timers --------------------------------------- */
ISR(TIMER0_OVF_vect){
  PORTD  ^= (1 << PD5); // toggle pin
  TCNT0 = freq_mosfet; //2400 Hz on mosfet
}

ISR(TIMER1_OVF_vect){
	PCF_GetDateTime(&pcfDateTime);
	 set_clr();
	TCNT1 = freq_rtc; // 0.99 Hz tick RTC
}
/* ----------------- flicker anod and set number ------------------------ */
void set_anode_vt(int H1,int H2,int M1,int M2,int S1,int S2){
  set_decoder(H1);
  PORTD |= (1<<PD6);
  _delay_ms(del_vt);
  PORTD &= ~(1<<PD6);
  _delay_ms(del_vt);
  
  set_decoder(H2);
  PORTD |= (1<<PD7);
  _delay_ms(del_vt);
  PORTD &= ~(1<<PD7);
  _delay_ms(del_vt);
  
  set_decoder(M1);
  PORTB |= (1<<PB0);
  _delay_ms(del_vt);
  PORTB &= ~(1<<PB0);
  _delay_ms(del_vt);
  
  set_decoder(M2);
  PORTB |= (1<<PB1);
  _delay_ms(del_vt);
  PORTB &= ~(1<<PB1);
  _delay_ms(del_vt);
  
  set_decoder(S1);
  PORTC |= (1<<PC0);
  _delay_ms(del_vt);
  PORTC &= ~(1<<PC0);
  _delay_ms(del_vt);
  
  set_decoder(S2);
  PORTC |= (1<<PC1);
  _delay_ms(del_vt);
  PORTC &= ~(1<<PC1);
  _delay_ms(del_vt);
}
void set_time_h(int H1,int H2,int M1,int M2,int S1,int S2){
  set_decoder(H1);
  PORTD |= (1<<PD6);
  _delay_ms(del_vt);
  PORTD &= ~(1<<PD6);
  _delay_ms(del_vt);

  set_decoder(H2);
  PORTD |= (1<<PD7);
  _delay_ms(del_vt);
  PORTD &= ~(1<<PD7);
  _delay_ms(del_vt);
  
  PORTB &= ~(1<<PB0);
  PORTB &= ~(1<<PB1);
  PORTC &= ~(1<<PC0);
  PORTC &= ~(1<<PC1);
}
void set_time_m(int H1,int H2,int M1,int M2,int S1,int S2){
  PORTD &= ~(1<<PD6);
  PORTD &= ~(1<<PD7);

  set_decoder(M1);
  PORTB |= (1<<PB0);
  _delay_ms(del_vt);
  PORTB &= ~(1<<PB0);
  _delay_ms(del_vt);
  
  set_decoder(M2);
  PORTB |= (1<<PB1);
  _delay_ms(del_vt);
  PORTB &= ~(1<<PB1);
  _delay_ms(del_vt);
  
  PORTC &= ~(1<<PC0);
  PORTC &= ~(1<<PC1);
}

void set_time_s(int H1,int H2,int M1,int M2,int S1,int S2){
  PORTD &= ~(1<<PD6);
  PORTD &= ~(1<<PD7);
  PORTB &= ~(1<<PB0);
  PORTB &= ~(1<<PB1);
  
  set_decoder(S1);
  PORTC |= (1<<PC0);
  _delay_ms(del_vt);
  PORTC &= ~(1<<PC0);
  _delay_ms(del_vt);
  
  set_decoder(S2);
  PORTC |= (1<<PC1);
  _delay_ms(del_vt);
  PORTC &= ~(1<<PC1);
  _delay_ms(del_vt);
}
void set_time_y(int M1,int M2,int S1,int S2){
	PORTD &= ~(1<<PD6);
	PORTD &= ~(1<<PD7);
	
	set_decoder(M1);
	PORTB |= (1<<PB0);
	_delay_ms(del_vt);
	PORTB &= ~(1<<PB0);
	_delay_ms(del_vt);
	
	set_decoder(M2);
	PORTB |= (1<<PB1);
	_delay_ms(del_vt);
	PORTB &= ~(1<<PB1);
	_delay_ms(del_vt);
	
	set_decoder(S1);
	PORTC |= (1<<PC0);
	_delay_ms(del_vt);
	PORTC &= ~(1<<PC0);
	_delay_ms(del_vt);
	
	set_decoder(S2);
	PORTC |= (1<<PC1);
	_delay_ms(del_vt);
	PORTC &= ~(1<<PC1);
	_delay_ms(del_vt);
}
/* ------------------ config K155ID1 ------------------------ */
void set_decoder(int num){
  if (num == 0)
  {
    PORTC |= (1<<PC2);
    PORTD &= ~(1<<PD0);
    PORTD &= ~(1<<PD1);
    PORTC &= ~(1<<PC3);
  }
  else if (num == 1)
  {
    PORTC &= ~(1<<PC2);
    PORTD &= ~(1<<PD0);
    PORTD &= ~(1<<PD1);
    PORTC &= ~(1<<PC3);
  }
  else if (num == 2)
  {
    PORTC |= (1<<PC2);
    PORTD &= ~(1<<PD0);
    PORTD &= ~(1<<PD1);
    PORTC |= (1<<PC3);
  }
  else if (num == 3)
  {
    PORTC &= ~(1<<PC2);
    PORTD &= ~(1<<PD0);
    PORTD &= ~(1<<PD1);
    PORTC |= (1<<PC3);
  }
  else if (num == 4)
  {
    PORTC |= (1<<PC2);
    PORTD |= (1<<PD0);
    PORTD |= (1<<PD1);
    PORTC &= ~(1<<PC3);
  }
  else if (num == 5)
  {
    PORTC &= ~(1<<PC2);
    PORTD |= (1<<PD0);
    PORTD |= (1<<PD1);
    PORTC &= ~(1<<PC3);
  }
  else if (num == 6)
  {
    PORTC |= (1<<PC2);
    PORTD &= ~(1<<PD0);
    PORTD |= (1<<PD1);
    PORTC &= ~(1<<PC3);
  }
  else if (num == 7)
  {
    PORTC &= ~(1<<PC2);
    PORTD &= ~(1<<PD0);
    PORTD |= (1<<PD1);
    PORTC &= ~(1<<PC3);
  }
  else if (num == 8)
  {
    PORTC |= (1<<PC2);
    PORTD |= (1<<PD0);
    PORTD &= ~(1<<PD1);
    PORTC &= ~(1<<PC3);
  }
  else if (num == 9)
  {
    PORTC &= ~(1<<PC2);
    PORTD |= (1<<PD0);
    PORTD &= ~(1<<PD1);
    PORTC &= ~(1<<PC3);
  }
}
/* ------------------ config WS2812 ------------------------ */
//unsigned long int rgb_list1[6]={red,red,blue,blue,green,green};
void set_clr() {
	unsigned long int a;
	for (int j=0;j<6;j++) {
		a = 0b1000000000000000000000000;
		for (int i=0;i<24;i++) {
			a=a>>1;
			if (rgb_list1[j]&a) {
				PORTB |= (1<<PB2);
				_delay_us(0.8);
				PORTB &= ~(1<<PB2);
			}
			else {
				PORTB |= (1<<PB2);
				_delay_us(0.3);
				PORTB &= ~(1<<PB2);
			}
		}
	}
}
/* ------------------------------------------------------------------------- */
int main(void)
{
  DDRB = 0xff; //all ports B - output
  DDRC = 0xff; //all ports C - output
  DDRD = 0xff; //all ports D - output
  DDRD &= ~(1<<4); //PD4 - input (button 1)
  DDRD &= ~(1<<3); //PD3 - input (button 2)
  DDRD &= ~(1<<2); //PD2 - input (button 3)
  PORTD = 0b00011100;
  /*EEPROM_write_word(0,blue); //  for primary programming eeprom
  EEPROM_write_word(3,red);
  EEPROM_write_word(6,green);
  EEPROM_write_word(9,aqumarine);
  EEPROM_write_word(12,yellow);
  EEPROM_write_word(15,purpure);*/
  _delay_ms(20);
  rgb_list1[0] = EEPROM_read_word(0);
  rgb_list1[1] = EEPROM_read_word(0);
  rgb_list1[2] = EEPROM_read_word(3);
  rgb_list1[3] = EEPROM_read_word(3);
  rgb_list1[4] = EEPROM_read_word(6);
  rgb_list1[5] = EEPROM_read_word(6);

  I2C_Init();
  init_timer0();
  init_timer1();
  sei(); // global interrupts

  _delay_ms(20);
  while (1)
  {
    //--------> Button MENU TIME select <--------
    if ((PIND & (1 << 4)) == 0 && menuTimePressed < 3 && menuTime == true){
      _delay_ms(50);		// ���������� ��������
      if ((PIND & (1 << 4)) == 0){	// ����� ��������� �������
        menuTimePressed += 1;
        menuCommon = false;
      }
      while((PIND & (1 << 4)) == 0)  // ���� ���������� ������
      {}
    }
    else if ((PIND & (1 << 4)) == 0 && menuTimePressed >= 3 && menuTime == true){
      _delay_ms(50);
      if ((PIND & (1 << 4)) == 0){
        menuTimePressed=0;
        menuCommon = false;
      }
      while((PIND & (1 << 4)) == 0)
      {}
    }
    
    if (menuTimePressed == 0 && menuTime == true){
      set_anode_vt(pcfDateTime.hour/10,pcfDateTime.hour%10,pcfDateTime.minute/10,pcfDateTime.minute%10,pcfDateTime.second/10,pcfDateTime.second%10);
      hourMode = false;
      minuteMode = false;
    }
    else if(menuTimePressed == 1 && menuTime == true){
      set_time_h(pcfDateTime.hour/10,pcfDateTime.hour%10,pcfDateTime.minute/10,pcfDateTime.minute%10,pcfDateTime.second/10,pcfDateTime.second%10);
      hourMode = true;
      minuteMode = false;
    }
    else if(menuTimePressed == 2 && menuTime == true){
      set_time_m(pcfDateTime.hour/10,pcfDateTime.hour%10,pcfDateTime.minute/10,pcfDateTime.minute%10,pcfDateTime.second/10,pcfDateTime.second%10);
      hourMode = false;
      minuteMode = true;
    }
    else if(menuTimePressed == 3 && menuTime == true)
      set_time_s(pcfDateTime.hour/10,pcfDateTime.hour%10,pcfDateTime.minute/10,pcfDateTime.minute%10,pcfDateTime.second/10,pcfDateTime.second%10);

    //--------> Button setting hour <--------
    if ((PIND & (1 << 3)) == 0 && pcfDateTime.hour < 24 && hourMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.hour += 1;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
    else if ((PIND & (1 << 3)) == 0 && pcfDateTime.hour >= 24 && hourMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.hour = 0;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
    //--------> Button setting minute <--------
    if ((PIND & (1 << 3)) == 0 && pcfDateTime.minute < 60 && minuteMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.minute += 1;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
    else if ((PIND & (1 << 3)) == 0 && pcfDateTime.minute >= 60 && minuteMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.minute = 0;
        PCF_SetDateTime(&pcfDateTime);
      }
    }

    //--------> Button MENU DATE select <--------
    if ((PIND & (1 << 4)) == 0 && menuDatePressed < 3 && menuDate == true){
      _delay_ms(50);
      if ((PIND & (1 << 4)) == 0){
        menuDatePressed += 1;
        menuCommon = false;
      }
      while((PIND & (1 << 4)) == 0)
      {}
    }
    else if ((PIND & (1 << 4)) == 0 && menuDatePressed >= 3 && menuDate == true){
      _delay_ms(50);
      if ((PIND & (1 << 4)) == 0){
        menuDatePressed=0;
        menuCommon = false;
      }
      while((PIND & (1 << 4)) == 0)
      {}
    }
    
    if (menuDatePressed == 0 && menuDate == true){
      set_anode_vt(pcfDateTime.day/10,pcfDateTime.day%10,pcfDateTime.month/10,pcfDateTime.month%10,(pcfDateTime.year/10)%10,pcfDateTime.year%10);
      dayMode = false;
      monthMode = false;
      yearMode = false;
    }
    else if(menuDatePressed == 1 && menuDate == true){
      set_time_h(pcfDateTime.day/10,pcfDateTime.day%10,pcfDateTime.month/10,pcfDateTime.month%10,pcfDateTime.year/10,pcfDateTime.year%10);
      dayMode = true;
      monthMode = false;
      yearMode = false;
    }
    else if(menuDatePressed == 2 && menuDate == true){
      set_time_m(pcfDateTime.day/10,pcfDateTime.day%10,pcfDateTime.month/10,pcfDateTime.month%10,pcfDateTime.year/10,pcfDateTime.year%10);
      dayMode = false;
      monthMode = true;
      yearMode = false;
    }
    else if(menuDatePressed == 3 && menuDate == true){
	  set_time_y(pcfDateTime.year/1000,(pcfDateTime.year/100)%10,(pcfDateTime.year/10)%10,pcfDateTime.year%10);
      dayMode = false;
      monthMode = false;
      yearMode = true;
    }
    //--------> Button setting day <--------
    if ((PIND & (1 << 3)) == 0 && pcfDateTime.day < 31 && dayMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.day += 1;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
    else if ((PIND & (1 << 3)) == 0 && pcfDateTime.day >= 31 && dayMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.day = 0;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
    //--------> Button setting month <--------
    if ((PIND & (1 << 3)) == 0 && pcfDateTime.month < 12 && monthMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.month += 1;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
    else if ((PIND & (1 << 3)) == 0 && pcfDateTime.month >= 12 && monthMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.month = 0;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
    //--------> Button setting year <--------
    if ((PIND & (1 << 3)) == 0 && pcfDateTime.year < 2050 && yearMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.year += 1;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
    else if ((PIND & (1 << 3)) == 0 && pcfDateTime.year >= 2050 && yearMode == true){
      _delay_ms(50);
      if ((PIND & (1 << 3)) == 0){
        pcfDateTime.year = 2000;
        PCF_SetDateTime(&pcfDateTime);
      }
    }
	//--------> Button MENU LED select <--------
	if ((PIND & (1 << 4)) == 0 && menLedPressed < 2 && menuLed == true){
		_delay_ms(50);
		if ((PIND & (1 << 4)) == 0){
			menLedPressed += 1;
			menuCommon = false;
		}
		while((PIND & (1 << 4)) == 0)
		{}
	}
	else if ((PIND & (1 << 4)) == 0 && menLedPressed >= 2 && menuLed == true){
		_delay_ms(50);
		if ((PIND & (1 << 4)) == 0){
			menLedPressed=0;
			menuCommon = false;
		}
		while((PIND & (1 << 4)) == 0)
		{}
	}
	
	if (menLedPressed == 0 && menuLed == true){
		set_anode_vt(0,0,0,0,1,1);
		led1Mode = true;
		led2Mode = false;
		led3Mode = false;
	}
	else if(menLedPressed == 1 && menuLed == true){
		set_anode_vt(0,0,1,1,0,0);
		led1Mode = false;
		led2Mode = true;
		led3Mode = false;
	}
	else if(menLedPressed == 2 && menuLed == true){
		set_anode_vt(1,1,0,0,0,0);
		led1Mode = false;
		led2Mode = false;
		led3Mode = true;
	}
	//--------> Button setting led1 <--------
	if ((PIND & (1 << 3)) == 0 && led1count == 0 && led1Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led1count += 1;
			EEPROM_write_word(0,blue);
			rgb_list1[0] = EEPROM_read_word(0);
			rgb_list1[1] = EEPROM_read_word(0);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led1count == 1 && led1Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led1count += 1;
			EEPROM_write_word(0,red);
			rgb_list1[0] = EEPROM_read_word(0);
			rgb_list1[1] = EEPROM_read_word(0);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led1count == 2 && led1Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led1count += 1;
			EEPROM_write_word(0,green);
			rgb_list1[0] = EEPROM_read_word(0);
			rgb_list1[1] = EEPROM_read_word(0);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led1count == 3 && led1Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led1count += 1;
			EEPROM_write_word(0,aqumarine);
			rgb_list1[0] = EEPROM_read_word(0);
			rgb_list1[1] = EEPROM_read_word(0);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led1count == 4 && led1Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led1count += 1;
			EEPROM_write_word(0,yellow);
			rgb_list1[0] = EEPROM_read_word(0);
			rgb_list1[1] = EEPROM_read_word(0);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led1count == 5 && led1Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led1count = 0;
			EEPROM_write_word(0,purpure);
			rgb_list1[0] = EEPROM_read_word(0);
			rgb_list1[1] = EEPROM_read_word(0);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	//--------> Button setting led2 <--------
	if ((PIND & (1 << 3)) == 0 && led2count == 0 && led2Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led2count += 1;
			EEPROM_write_word(3,blue);
			rgb_list1[2] = EEPROM_read_word(3);
			rgb_list1[3] = EEPROM_read_word(3);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led2count == 1 && led2Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led2count += 1;
			EEPROM_write_word(3,red);
			rgb_list1[2] = EEPROM_read_word(3);
			rgb_list1[3] = EEPROM_read_word(3);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led2count == 2 && led2Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led2count += 1;
			EEPROM_write_word(3,green);
			rgb_list1[2] = EEPROM_read_word(3);
			rgb_list1[3] = EEPROM_read_word(3);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led2count == 3 && led2Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led2count += 1;
			EEPROM_write_word(3,aqumarine);
			rgb_list1[2] = EEPROM_read_word(3);
			rgb_list1[3] = EEPROM_read_word(3);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led2count == 4 && led2Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led2count += 1;
			EEPROM_write_word(3,yellow);
			rgb_list1[2] = EEPROM_read_word(3);
			rgb_list1[3] = EEPROM_read_word(3);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led2count == 5 && led2Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led2count = 0;
			EEPROM_write_word(3,purpure);
			rgb_list1[2] = EEPROM_read_word(3);
			rgb_list1[3] = EEPROM_read_word(3);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	//--------> Button setting led3 <--------
	if ((PIND & (1 << 3)) == 0 && led3count == 0 && led3Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led3count += 1;
			EEPROM_write_word(6,blue);
			rgb_list1[4] = EEPROM_read_word(6);
			rgb_list1[5] = EEPROM_read_word(6);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led3count == 1 && led3Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led3count += 1;
			EEPROM_write_word(6,red);
			rgb_list1[4] = EEPROM_read_word(6);
			rgb_list1[5] = EEPROM_read_word(6);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led3count == 2 && led3Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led3count += 1;
			EEPROM_write_word(6,green);
			rgb_list1[4] = EEPROM_read_word(6);
			rgb_list1[5] = EEPROM_read_word(6);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led3count == 3 && led3Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led3count += 1;
			EEPROM_write_word(6,aqumarine);
			rgb_list1[4] = EEPROM_read_word(6);
			rgb_list1[5] = EEPROM_read_word(6);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led3count == 4 && led3Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led3count += 1;
			EEPROM_write_word(6,yellow);
			rgb_list1[4] = EEPROM_read_word(6);
			rgb_list1[5] = EEPROM_read_word(6);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
	else if ((PIND & (1 << 3)) == 0 && led3count == 5 && led3Mode == true){
		_delay_ms(50);
		if ((PIND & (1 << 3)) == 0){
			led3count = 0;
			EEPROM_write_word(6,purpure);
			rgb_list1[4] = EEPROM_read_word(6);
			rgb_list1[5] = EEPROM_read_word(6);
		}
		while((PIND & (1 << 3)) == 0)
		{}
	}
    //--------> Button MENU <--------
    if ((PIND & (1 << 2)) == 0 && menuCommonPressed < 2){
      _delay_ms(50);
      if ((PIND & (1 << 2)) == 0){
        menuCommonPressed += 1;
        menuCommon = true;
      }
      while((PIND & (1 << 2)) == 0)
      {}
    }
    else if ((PIND & (1 << 2)) == 0 && menuCommonPressed >= 2){
      _delay_ms(50);
      if ((PIND & (1 << 2)) == 0){
        menuCommonPressed = 0;
        menuCommon = true;
      }
      while((PIND & (1 << 2)) == 0)
      {}
    }

    if (menuCommonPressed == 0 && menuCommon == true){
      set_anode_vt(pcfDateTime.hour/10,pcfDateTime.hour%10,pcfDateTime.minute/10,pcfDateTime.minute%10,pcfDateTime.second/10,pcfDateTime.second%10);
	  menuTime = true;
	  menuDate = false;
	  menuLed = false;
	  led1Mode = false;
	  led2Mode = false;
	  led3Mode = false;
	}
    else if (menuCommonPressed == 1 && menuCommon == true){
      set_anode_vt(pcfDateTime.day/10,pcfDateTime.day%10,pcfDateTime.month/10,pcfDateTime.month%10,(pcfDateTime.year/10)%10,pcfDateTime.year%10);
	  menuTime = false;
	  menuDate = true;
	  menuLed = false;
	  led1Mode = false;
	  led2Mode = false;
	  led3Mode = false;
	}
	else if (menuCommonPressed == 2 && menuCommon == true){
		set_anode_vt(0,0,0,0,1,1);
		menuTime = false;
		menuDate = false;
		menuLed = true;
	}
  }
} 
