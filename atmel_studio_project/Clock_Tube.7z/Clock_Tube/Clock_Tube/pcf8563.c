#include <avr/io.h>
#include <pcf8563.h>
#define BinToBCD(bin) ((((bin) / 10) << 4) + ((bin) % 10))

// ------------------ I2C AVR --------------------------------
void I2C_Init(void){
  TWBR = 0xc;
  TWSR &= ~((1<<TWPS1) | (1<<TWPS0));
}

void I2C_Start(void){
  TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTA);
  while(!(TWCR&(1<<TWINT)));
}

void I2C_Stop(void){
  TWCR = (1<<TWINT)|(1<<TWSTO)|(1<<TWEN);
  while ((TWCR & (1<<TWSTO)));
}

void I2C_Write(uint8_t byte ){
  TWDR = byte;                  // запись байтов в регистр данных
  TWCR = (1<<TWINT)|(1<<TWEN);  // включим передачу данных
  while(!(TWCR&(1<<TWINT)));    //подождем пока установится TWIN
}

uint8_t I2C_Read(uint8_t ack){
  TWCR = (1<<TWINT) | (1<<TWEN) | (((ack ? 1 : 0)<<TWEA));
  while (!(TWCR & (1<<TWINT)));
  return TWDR;
}
// ------------------ PCF8563 -------------------------------
void PCF_Write(uint8_t addr, uint8_t *data, uint8_t count) {
  I2C_Start();
  I2C_Write(pcf8563_write_addr);
  I2C_Write(addr);
  while (count) {
    count--;
    I2C_Write(*data);
    data++;
  }
  I2C_Stop();
}

void PCF_Read(uint8_t addr, uint8_t *data, uint8_t count) {
  I2C_Start();
  I2C_Write(pcf8563_write_addr);
  I2C_Write(addr);
  I2C_Stop();
  I2C_Start();
  I2C_Write(pcf8564_read_addr);
  while (count)
  {
    count--;
    *data = I2C_Read(count);
    data++;
  }
  I2C_Stop();
}

uint8_t PCF_SetDateTime(PCF_DateTime *dateTime)
{
	if (dateTime->second >= 60 || dateTime->minute >= 60 || dateTime->hour >= 24 || dateTime->day > 32 || dateTime->weekday > 6 || dateTime->month > 12 || dateTime->year < 1900 || dateTime->year >= 2100)
	{
		return 1;
	}

	uint8_t buffer[7];

	buffer[0] = BinToBCD(dateTime->second) & 0x7F;
	buffer[1] = BinToBCD(dateTime->minute) & 0x7F;
	buffer[2] = BinToBCD(dateTime->hour) & 0x3F;
	buffer[3] = BinToBCD(dateTime->day) & 0x3F;
	buffer[4] = BinToBCD(dateTime->weekday) & 0x07;
	buffer[5] = BinToBCD(dateTime->month) & 0x1F;

	if (dateTime->year >= 2000)
	{
		buffer[5] |= 0x80;
		buffer[6] = BinToBCD(dateTime->year - 2000);
	}
	else
	{
		buffer[6] = BinToBCD(dateTime->year - 1900);
	}

	PCF_Write(0x02, buffer, sizeof(buffer));

	return 0;
}

uint8_t PCF_GetDateTime(PCF_DateTime *dateTime)
{
	uint8_t buffer[7];

	PCF_Read(0x02, buffer, sizeof(buffer));

	dateTime->second = (((buffer[0] >> 4) & 0x07) * 10) + (buffer[0] & 0x0F);
	dateTime->minute = (((buffer[1] >> 4) & 0x07) * 10) + (buffer[1] & 0x0F);
	dateTime->hour = (((buffer[2] >> 4) & 0x03) * 10) + (buffer[2] & 0x0F);
	dateTime->day = (((buffer[3] >> 4) & 0x03) * 10) + (buffer[3] & 0x0F);
	dateTime->weekday = (buffer[4] & 0x07);
	dateTime->month = ((buffer[5] >> 4) & 0x01) * 10 + (buffer[5] & 0x0F);
	dateTime->year = 1900 + ((buffer[6] >> 4) & 0x0F) * 10 + (buffer[6] & 0x0F);

	if (buffer[5] &  0x80)
	{
		dateTime->year += 100;
	}

	if (buffer[0] & 0x80) //Clock integrity not guaranted
	{
		return 1;
	}

	return 0;
}
