/*
 * eeprom.c
 *
 * Created: 05.10.2023 16:35:59
 *  Author: g1enden
 */ 

#include <eeprom.h>

void EEPROM_write(unsigned int ucAddress, unsigned char ucData)
{
	/* Wait for completion of previous write */
	while(EECR & (1<<EEPE));
	/* Set Programming mode */
	EECR = (0<<EEPM1)|(0<<EEPM0);
	/* Set up address and data registers */
	EEAR = ucAddress;
	EEDR = ucData;
	/* Write logical one to EEMPE */
	EECR |= (1<<EEMPE);
	/* Start eeprom write by setting EEPE */
	EECR |= (1<<EEPE);
}

void EEPROM_write_word(unsigned int ucAddress, uint32_t ucData)
{
	EEPROM_write(ucAddress, (unsigned char) ucData);
	unsigned char dt = ucData>>8;
	EEPROM_write(ucAddress+1, dt);
	unsigned char dt2 = ucData>>16;
	EEPROM_write(ucAddress+2, dt2);
}

unsigned char EEPROM_read(unsigned int ucAddress)
{
	/* Wait for completion of previous write */
	while(EECR & (1<<EEPE));
	/* Set up address register */
	EEAR = ucAddress;
	/* Start eeprom read by writing EERE */
	EECR |= (1<<EERE);
	/* Return data from data register */
	return EEDR;
}

uint32_t EEPROM_read_word(unsigned int ucAddress)
{
	uint32_t dt2 = EEPROM_read(ucAddress+2)*65536;
	uint16_t dt = EEPROM_read(ucAddress+1)*256;
	asm("nop");
	dt2 = dt2 + dt + EEPROM_read(ucAddress);
	return dt2;
}
