#ifndef PCF8563_H_
#define PCF8563_H_

#define pcf8563_write_addr 0xA2
#define pcf8564_read_addr 0xA3

typedef struct {
	uint8_t second;
	uint8_t minute;
	uint8_t hour;
	uint8_t day;
	uint8_t weekday;
	uint8_t month;
	uint16_t year;
} PCF_DateTime;

void PCF_Write(uint8_t addr, uint8_t *data, uint8_t count);
void PCF_Read(uint8_t addr, uint8_t *data, uint8_t count);
uint8_t PCF_GetDateTime(PCF_DateTime *dateTime);
uint8_t PCF_SetDateTime(PCF_DateTime *dateTime);

#endif
