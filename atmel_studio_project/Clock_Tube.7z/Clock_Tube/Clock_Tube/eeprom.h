/*
 * eeprom.h
 *
 * Created: 05.10.2023 16:36:06
 *  Author: g1enden
 */ 


#ifndef EEPROM_H_
#define EEPROM_H_
#include <avr/io.h>
void EEPROM_write(unsigned int ucAddress, unsigned char ucData);
void EEPROM_write_word(unsigned int ucAddress, uint32_t ucData);
unsigned char EEPROM_read(unsigned int ucAddress);
uint32_t EEPROM_read_word(unsigned int ucAddress);

#endif /* EEPROM_H_ */